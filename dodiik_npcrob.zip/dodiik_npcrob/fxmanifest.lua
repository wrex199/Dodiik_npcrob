fx_version 'cerulean'
game 'gta5'

author 'Dodiik)'

description 'Npc robbery'

shared_script '@ox_lib/init.lua'

client_script 'cl.lua'

server_script 'sv.lua'

lua54 'yes'
