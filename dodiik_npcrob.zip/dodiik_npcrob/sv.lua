
local items = {
    {
        itemName = 'money',
        itemRandomAmount = {10, 25}
    },
    {
        itemName = 'money',
        itemRandomAmount = {10, 25}
    },
    {
        itemName = 'money',
        itemRandomAmount = {10, 25}
    },
    {
        itemName = 'money',
        itemRandomAmount = {25, 50}
    },
    {
        itemName = 'money',
        itemRandomAmount = {25, 50}
    },
    {
        itemName = 'money',
        itemRandomAmount = {50, 100}
    },
    {
        itemName = 'weed_joint',
        itemRandomAmount = {1, 3}
    },
    {
        itemName = 'weed_joint',
        itemRandomAmount = {1, 3}
    },
    {
        itemName = 'gold_watch',
        itemRandomAmount = {1, 1}
    },
    {
        itemName = 'phone',
        itemRandomAmount = {1, 1}
    },
    {
        itemName = 'phone',
        itemRandomAmount = {1, 1}
    },
    
}

RegisterNetEvent('n-npcRob:server:robNpc', function(pCoords, Ped,oCoords, robbed)
    local _source = source

    if #(GetEntityCoords(GetPlayerPed(_source)) - pCoords) > 0.5 then
        return false
    end
    if Ped ~= nil then
        return false
    end
    if oCoords ~= oCoords then
        return false
    end
    if not robbed then
        return false
    end

    for i = 1, 3 do
        local randomItem = math.random(1, #items)
        local item = items[randomItem]
        local amount = math.random(item.itemRandomAmount[1], item.itemRandomAmount[2])

        exports.ox_inventory:AddItem(_source, item.itemName, amount)
        exports['8bit_core']:sendToDiscord({
            webhook = 'https://discord.com/api/webhooks/1154136993006112908/wBz7kNDmxgzKFS9lf-waTCEs_QhdtFjMx8zB9zWZZ53oXzGa3smq9uyHrJVTogEftnZo',
            name = 'Okrádaní NPC',
            title = 'Hráč okradl NPC',
            desc = '`Item:` '.. item.itemName .. ' \n`Počet:` **' .. amount .. 'x**',
            color = '43008'
        }, _source)
    end
end)